# FAQ-GPT — Hybrid Semantic AI Retrieval System

A production-ready FAQ retrieval engine. Upload documents (PDF, image, plain text), automatically generate Q&A pairs using **Google Gemini 2.0 Flash**, then search them with a hybrid of **local MiniLM semantic embeddings** and **BM25 keyword scoring** — all running in the browser. When local confidence is low, the system falls back to Gemini automatically.

---

## Architecture Overview

| Layer | Technology | Role |
|---|---|---|
| Frontend | Vanilla HTML + CSS + ES Modules | UI, file handling, search |
| Embeddings | `@xenova/transformers` (MiniLM-L6-v2) | In-browser semantic vectors |
| Keyword Search | Pure-JS BM25 | Zero-dependency keyword ranking |
| Hybrid Score | 70% semantic + 30% BM25 | FAQ retrieval, threshold routing |
| FAQ Generation | Google Gemini 2.0 Flash | Extract Q&A from document chunks |
| Fallback Search | Google Gemini 2.0 Flash | Answer queries beyond local match |
| OCR | Tesseract.js 4.1.1 | Extract text from images |
| PDF Parsing | PDF.js 3.11.174 | Page-by-page PDF text extraction |
| Backend | Node.js + Express | API, session memory, retry logic |
| Storage | IndexedDB (browser) | FAQ + embeddings cache |

---

## File Structure

```
faq-system/
├── frontend/
│   ├── index.html          # Full SPA shell, all CDN scripts
│   ├── styles.css          # Complete design system (dark navy theme)
│   ├── app.js              # Main orchestration module (ES module)
│   ├── search.js           # MiniLM loader, BM25, hybrid search, IDB cache
│   ├── utils.js            # Shared helpers: chunkText, toast, idb*, progress, etc.
│   └── faqData/
│       ├── faqs.json       # 5 sample FAQ entries (pre-loaded on first boot)
│       └── embeddings.json # Empty placeholder (runtime embeddings in IndexedDB)
├── backend/
│   ├── server.js           # Express setup, CORS, static serving, error handler
│   ├── config.js           # All constants, loaded from .env
│   ├── routes.js           # /health, /api/generate-faq, /api/answer, /api/improve
│   ├── package.json        # Dependencies: express, @google/generative-ai, cors, dotenv
│   └── .env.example        # Environment variable template
├── start.bat               # Windows one-click launcher
└── README.md               # This file
```

---

## Prerequisites

- **Node.js v18+** — [Download](https://nodejs.org/)
- A **Google Gemini API Key** — [Get one free](https://aistudio.google.com/app/apikey)
- A modern browser (Chrome, Edge, Firefox) with internet access (for CDN model downloads)

---

## Setup & Run

### Step 1 — Install backend dependencies

```bash
cd backend
npm install
```

### Step 2 — Configure your API key

Copy the example environment file:

```bash
# Windows
copy .env.example .env

# macOS / Linux
cp .env.example .env
```

Open `.env` and set your Gemini API key:

```env
GEMINI_API_KEY=AIzaSy_YOUR_KEY_HERE
```

### Step 3 — Start the backend server

```bash
# From the backend/ directory:
npm start
```

The server starts on **`http://localhost:3000`**.  
It automatically serves the `frontend/` folder as static files — no separate web server needed.

### Step 4 — Open the app

Visit: **[http://localhost:3000](http://localhost:3000)**

> **Windows users:** Double-click `start.bat` in the project root to launch the backend and open the browser automatically.

---

## Configuration Reference

All settings live in `backend/.env` (copy from `.env.example`):

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | Express server port |
| `GEMINI_API_KEY` | *(required)* | Your Google Gemini API key |
| `GEMINI_MODEL` | `gemini-3.5-flash` | Gemini model name |
| `SESSION_TTL_MS` | `1800000` | Session expiry — 30 minutes |
| `MAX_OUT_TOKENS` | `2048` | Max tokens per Gemini response |
| `PARALLEL_LIMIT` | `5` | Max concurrent chunk requests |
| `RETRY_ATTEMPTS` | `3` | Retry count per chunk |
| `CHUNK_TIMEOUT_MS` | `30000` | Per-attempt timeout (30s) |
| `RETRY_BASE_MS` | `1000` | Base delay for exponential backoff |
| `CONTACT_EMAIL` | `contact_us@mygmail.com` | Fallback contact shown when unanswerable |
| `CORS_ORIGIN` | `*` | CORS allowed origin |

---

## API Endpoints

### `GET /health`
Health check. Returns server status metrics.

```json
{ "status": "healthy", "model": "gemini-3.5-flash", "sessions": 0, "parallel": 5, "retries": 3, "timeout": 30000 }
```

### `POST /api/generate-faq`
Generate FAQ pairs from document text chunks.

**Body:**
```json
{
  "chunks": ["text chunk 1...", "text chunk 2..."],
  "sources": ["document.pdf", "document.pdf"],
  "sessionId": "ABCD1234"
}
```

**Response:**
```json
{
  "faqs": [{ "question": "...", "answer": "...", "chunkIndex": 0, "source": "document.pdf" }],
  "stats": { "chunks": 10, "total": 87, "skipped": 0, "ms": 4200 }
}
```

### `POST /api/answer`
Gemini fallback answering with session context.

**Body:** `{ "query": "...", "context": "...", "sessionId": "ABCD1234" }`  
**Response:** `{ "answer": "...", "sessionId": "ABCD1234" }`

### `POST /api/improve`
Improved answer on thumbs-down feedback.

**Body:** `{ "query": "...", "context": "...", "previousAnswer": "...", "sessionId": "ABCD1234" }`  
**Response:** `{ "answer": "...", "sessionId": "ABCD1234" }`

---

## Feature Overview

### Document Upload
- Drag & drop or click-to-browse
- Supported: `.pdf`, `.txt`, `.png`, `.jpg`, `.jpeg`
- Duplicate filenames silently ignored
- Unsupported formats: error toast, file not added
- Status badges: ⏳ Pending → ✅ Ready / ⚠️ Warning / ❌ Failed

### Text Extraction
- **PDF.js** — page-by-page, logs every 10 pages; scanned PDF detection
- **Tesseract.js** — real-time OCR progress %; low confidence / short text warnings
- **TXT** — direct read; short content warning if < 20 chars

### FAQ Generation
- Text chunked into ~400-word sentence-boundary segments
- All chunks sent in one request; backend processes up to 5 in parallel
- Per-chunk: 3 retries, 30s timeout, exponential backoff (1s → 2s → 4s)
- Failed chunks silently skipped; info toast shows skip count
- FAQs appear grouped by source document

### Hybrid Search
- **Semantic (70%):** MiniLM cosine similarity on Float32Array embeddings
- **Keyword (30%):** BM25 score normalized to [0,1]
- Score ≥ 0.75 → ⚡ Local Match (instant, no API call)
- Score < 0.75 → 🤖 Gemini fallback
- Thumbs-down → ✨ Improved (calls `/api/improve`)

### Session Memory
- 8-char random `sessionId` generated on page load
- Backend stores up to 10 conversation turns per session
- Sessions expire after 30 minutes of inactivity

### Prompt Injection Safety
All user inputs are scanned for jailbreak patterns and replaced with `[input filtered]` before any Gemini call.

---

## Verification Test Cases

| # | Test | Expected |
|---|---|---|
| 1 | Upload valid PDF | ✅ Ready, text extracted |
| 2 | Upload scanned PDF | ⚠️ Warning toast, file kept |
| 3 | Upload PNG with text | OCR runs, FAQs generated |
| 4 | Upload blank image | ⚠️ Warning, no FAQs from it |
| 5 | Upload .docx file | Error toast, not added |
| 6 | Upload same file twice | Second silently ignored |
| 7 | Generate FAQs | FAQs grouped by filename |
| 8 | Backend offline | Clear error toast |
| 9 | Search matching FAQ exactly | ⚡ Local Match, instant |
| 10 | Empty search box | Error toast |
| 11 | Injection attempt in search | `[input filtered]`, safe reply |
| 12 | 👍 feedback | Thank you message, no API call |
| 13 | 👎 feedback | Improved answer in-place |
| 14 | Filter FAQs by keyword | Matching cards shown instantly |
| 15 | Export JSON | Downloads all FAQs as `faqs.json` |

---

## Troubleshooting

**MiniLM badge stays red / orange:**  
The model downloads from HuggingFace on first load (~90MB). Ensure your browser has internet access. It caches to the browser cache after the first download.

**Backend badge stays red:**  
Make sure `node server.js` is running in the `backend/` directory and your `.env` file has a valid `GEMINI_API_KEY`.

**FAQ generation returns 0 pairs:**  
Gemini may have returned unexpected output. Check the monospace log in the Generation Pipeline section — it logs per-chunk progress and any errors.

**OCR text is garbled:**  
Tesseract works best on high-contrast, clean images. Low-quality scans will show a `⚠️ Warning` with the confidence percentage.
