import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from './config.js';

const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);

async function executeResilientGemini(fn, attempts = 3, timeoutMs = 30000, baseDelay = 1000) {
  const models = [config.GEMINI_MODEL, 'gemini-3-flash', 'gemini-2.5-flash'];
  let lastError;

  for (let mIdx = 0; mIdx < models.length; mIdx++) {
    const modelName = models[mIdx];
    let attemptError;
    
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        console.log(`Executing resilient Gemini request using model: ${modelName} (attempt ${attempt}/${attempts})`);
        const response = await Promise.race([
          fn(modelName),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('TIMEOUT')), timeoutMs)
          )
        ]);
        return response;
      } catch (error) {
        attemptError = error;
        const is503 = error.status === 503 || 
                      error.message?.includes('503') || 
                      error.message?.includes('Service Unavailable') || 
                      error.message?.includes('high demand');
                      
        console.error(`Gemini call [model: ${modelName}] attempt ${attempt} failed: ${error.message}`);
        
        if (is503 && mIdx < models.length - 1) {
          console.warn(`Model ${modelName} is overloaded (503). Bypassing remaining retries and falling back to ${models[mIdx + 1]} immediately...`);
          break;
        }
        
        if (attempt < attempts) {
          const delay = baseDelay * Math.pow(2, attempt - 1);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    lastError = attemptError;
  }
  throw lastError;
}

async function runTest() {
  console.log('Testing resilient call wrapper...');
  
  const fn = async (modelName) => {
    const model = genAI.getGenerativeModel({ model: modelName });
    const result = await model.generateContent('Say hello world in JSON { "hello": "world" }');
    return result.response.text();
  };

  try {
    const text = await executeResilientGemini(fn);
    console.log('Success! Result:', text);
  } catch (err) {
    console.error('Resilient test failed entirely:', err);
  }
}

runTest();
