import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from './config.js';

async function test() {
  console.log('Testing with key:', config.GEMINI_API_KEY.substring(0, 10) + '...');
  console.log('Testing with model: gemini-3.5-flash');
  const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);
  const model = genAI.getGenerativeModel({ model: 'gemini-3.5-flash' });
  try {
    const result = await model.generateContent('Say hello world in JSON { "hello": "world" }');
    console.log('Success!', result.response.text());
  } catch (e) {
    console.error('ERROR:', e.message);
    if (e.status) console.error('Status:', e.status);
    if (e.statusText) console.error('StatusText:', e.statusText);
  }
}
test();
