import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from the backend root folder
dotenv.config({ path: path.join(__dirname, '.env') });

export const config = {
  PORT: parseInt(process.env.PORT || '3000', 10),
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
  GEMINI_MODEL: process.env.GEMINI_MODEL || 'gemini-3.5-flash',
  SESSION_TTL_MS: parseInt(process.env.SESSION_TTL_MS || '1800000', 10), // 30 mins
  MAX_OUT_TOKENS: parseInt(process.env.MAX_OUT_TOKENS || '2048', 10),
  PARALLEL_LIMIT: parseInt(process.env.PARALLEL_LIMIT || '5', 10),
  RETRY_ATTEMPTS: parseInt(process.env.RETRY_ATTEMPTS || '3', 10),
  CHUNK_TIMEOUT_MS: parseInt(process.env.CHUNK_TIMEOUT_MS || '30000', 10), // 30 seconds
  RETRY_BASE_MS: parseInt(process.env.RETRY_BASE_MS || '1000', 10), // 1 second
  CONTACT_EMAIL: process.env.CONTACT_EMAIL || 'contact_us@mygmail.com',
  CORS_ORIGIN: process.env.CORS_ORIGIN || '*'
};
