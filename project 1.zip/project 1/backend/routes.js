import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from './config.js';

const router = express.Router();

// Initialize the Gemini API client
const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);

// Active Session Memory Map
// sessionId -> { history: Array<{role: 'user'|'model', content: string}>, lastActive: number }
const sessions = new Map();

// Session cleaner: check every 5 minutes, delete sessions older than TTL
setInterval(() => {
  const now = Date.now();
  for (const [sessionId, session] of sessions.entries()) {
    if (now - session.lastActive > config.SESSION_TTL_MS) {
      sessions.delete(sessionId);
    }
  }
}, 5 * 60 * 1000);

/**
 * 10. Prompt Injection Safety Filter
 * Scans user inputs and sanitizes jailbreak patterns
 */
function sanitizeInput(input) {
  if (typeof input !== 'string') return '';
  
  const injectionPatterns = [
    /ignore\s+(?:previous|above|all)\s+instructions/gi,
    /you\s+are\s+now/gi,
    /pretend\s+(?:you\s+are|to\s+be)/gi,
    /act\s+as/gi,
    /jailbreak/gi,
    /system\s+prompt/gi,
    /reveal\s+your\s+(?:instructions|prompt)/gi,
    /disregard\s+(?:your|all)\s+(?:rules|guidelines)/gi
  ];

  let sanitized = input;
  let matched = false;

  for (const pattern of injectionPatterns) {
    if (pattern.test(sanitized)) {
      sanitized = sanitized.replace(pattern, '[input filtered]');
      matched = true;
    }
  }

  return sanitized;
}

/**
 * Helper to get or initialize session
 */
function getOrCreateSession(sessionId) {
  const cleanId = sanitizeInput(sessionId) || 'default';
  let session = sessions.get(cleanId);
  if (!session) {
    session = { history: [], lastActive: Date.now() };
    sessions.set(cleanId, session);
  } else {
    session.lastActive = Date.now();
  }
  return session;
}

/**
 * Helper to update session history, keeping at most 10 turns (20 entries)
 */
function updateSessionHistory(session, role, content) {
  session.history.push({ role, content });
  // Each turn has user + model content, so 10 turns = 20 entries
  if (session.history.length > 20) {
    session.history = session.history.slice(session.history.length - 20);
  }
}

/**
 * Build compact history for Gemini - only the last N turns
 */
function buildHistory(session, maxTurns = 3) {
  const items = session.history.slice(0, -1); // exclude the latest user message
  // Take only last maxTurns pairs (each pair = user + model)
  const start = Math.max(0, items.length - maxTurns * 2);
  return items.slice(start);
}

/**
 * 11. Resilient Gemini API Call wrapper
 * Executes a Gemini API function with retry, timeout, and model fallback (gemini-3.5-flash -> gemini-1.5-flash).
 * If a 503 (high demand) error is encountered, it fails over immediately to the fallback model.
 */
async function executeResilientGemini(fn, attempts = config.RETRY_ATTEMPTS, timeoutMs = config.CHUNK_TIMEOUT_MS, baseDelay = config.RETRY_BASE_MS) {
  const models = [config.GEMINI_MODEL, 'gemini-2.5-flash'];
  let lastError;

  for (let mIdx = 0; mIdx < models.length; mIdx++) {
    const modelName = models[mIdx];
    let attemptError;
    
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        console.log(`Executing resilient Gemini request using model: ${modelName} (attempt ${attempt}/${attempts})`);
        const response = await Promise.race([
          fn(modelName),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('TIMEOUT')), timeoutMs)
          )
        ]);
        return response;
      } catch (error) {
        attemptError = error;
        const is503 = error.status === 503 || 
                      error.message?.includes('503') || 
                      error.message?.includes('Service Unavailable') || 
                      error.message?.includes('high demand');
                      
        console.error(`Gemini call [model: ${modelName}] attempt ${attempt} failed: ${error.message}`);
        
        // If it's a 503 (high demand) and we have a fallback model available,
        // bypass further retries for this model and proceed to fallback immediately!
        if (is503 && mIdx < models.length - 1) {
          console.warn(`Model ${modelName} is overloaded (503). Bypassing remaining retries and falling back to ${models[mIdx + 1]} immediately...`);
          break; // break the retry loop, move to next model
        }
        
        if (attempt < attempts) {
          const delay = baseDelay * Math.pow(2, attempt - 1);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    lastError = attemptError;
  }
  throw lastError;
}

/**
 * 12. Fast Resilient Wrapper for Chat/Answering Endpoints
 * Chat shouldn't hang for 90s. Fail quickly (e.g. 8s timeout) and fallback immediately on failure.
 */
async function executeFastResilientGemini(fn, timeoutMs = 8000) {
  const models = [config.GEMINI_MODEL, 'gemini-2.5-flash'];
  let lastError;

  for (let mIdx = 0; mIdx < models.length; mIdx++) {
    const modelName = models[mIdx];
    try {
      console.log(`Executing fast Gemini request using model: ${modelName}`);
      const response = await Promise.race([
        fn(modelName),
        new Promise((_, reject) => setTimeout(() => reject(new Error('TIMEOUT')), timeoutMs))
      ]);
      return response;
    } catch (error) {
      lastError = error;
      console.error(`Fast Gemini call [model: ${modelName}] failed: ${error.message}`);
      
      const is503 = error.status === 503 || 
                    error.message?.includes('503') || 
                    error.message?.includes('Service Unavailable') || 
                    error.message?.includes('high demand');
                    
      // If we have a fallback model, try it immediately
      if (mIdx < models.length - 1) {
        console.warn(`Fast call failed on ${modelName}. Trying fallback ${models[mIdx + 1]}...`);
        continue;
      }
    }
  }
  throw lastError;
}

/**
 * Concurrency Limiter
 * Processes tasks with maximum dynamic parallelism.
 */
async function limitConcurrency(tasks, limit) {
  const results = [];
  const executing = new Set();
  
  for (const task of tasks) {
    const p = Promise.resolve().then(() => task());
    results.push(p);
    executing.add(p);
    
    const clean = () => executing.delete(p);
    p.then(clean, clean);
    
    if (executing.size >= limit) {
      await Promise.race(executing);
    }
  }
  return Promise.all(results);
}

/**
 * Resilient JSON FAQ parsing and recovery helper.
 * Handles clean arrays, markdown wrapped arrays, object wrappers, and partial/truncated responses.
 */
function parseAndRecoverFAQs(rawText) {
  let cleanJsonText = rawText.trim();
  
  // Strip markdown code fences if present
  if (cleanJsonText.startsWith('```')) {
    cleanJsonText = cleanJsonText.replace(/^```(?:json)?\n?/i, '').replace(/\n?```$/i, '').trim();
  }

  // Helper to validate and clean faq objects
  const processFaqObj = (obj) => {
    if (!obj) return null;
    const q = (obj.question || obj.q || '').trim();
    const a = (obj.answer || obj.a || '').trim();
    if (q.length > 8 && a.length > 8) {
      return { question: q, answer: a };
    }
    return null;
  };

  // 1. Try standard JSON parse first
  try {
    const parsed = JSON.parse(cleanJsonText);
    if (Array.isArray(parsed)) {
      const results = parsed.map(processFaqObj).filter(Boolean);
      if (results.length > 0) return results;
    } else if (typeof parsed === 'object') {
      // Look for an array inside the object (e.g. { faqs: [...] })
      for (const key of Object.keys(parsed)) {
        if (Array.isArray(parsed[key])) {
          const results = parsed[key].map(processFaqObj).filter(Boolean);
          if (results.length > 0) return results;
        }
      }
    }
  } catch (e) {
    // Ignore and proceed to recovery methods
  }

  // 2. Try to extract array by finding first '[' and last ']'
  const firstBracket = cleanJsonText.indexOf('[');
  const lastBracket = cleanJsonText.lastIndexOf(']');
  if (firstBracket !== -1 && lastBracket !== -1 && lastBracket > firstBracket) {
    const arrayCandidates = cleanJsonText.substring(firstBracket, lastBracket + 1);
    try {
      const parsed = JSON.parse(arrayCandidates);
      if (Array.isArray(parsed)) {
        const results = parsed.map(processFaqObj).filter(Boolean);
        if (results.length > 0) return results;
      }
    } catch (e) {
      // Ignore
    }
  }

  // 3. Resilient Brace-Matching Recovery Parser for partial/truncated JSON
  const list = [];
  let depth = 0;
  let startIdx = -1;
  
  for (let i = 0; i < cleanJsonText.length; i++) {
    const char = cleanJsonText[i];
    if (char === '{') {
      if (depth === 0) {
        startIdx = i;
      }
      depth++;
    } else if (char === '}') {
      if (depth > 0) {
        depth--;
        if (depth === 0 && startIdx !== -1) {
          const objStr = cleanJsonText.substring(startIdx, i + 1);
          try {
            const parsedObj = JSON.parse(objStr);
            const cleaned = processFaqObj(parsedObj);
            if (cleaned) {
              list.push(cleaned);
            }
          } catch (e) {
            // Ignore parse errors for individual objects
          }
        }
      }
    }
  }

  return list;
}

/**
 * GET /health
 * Returns server metrics and health details
 */
router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    model: config.GEMINI_MODEL,
    sessions: sessions.size,
    parallel: config.PARALLEL_LIMIT,
    retries: config.RETRY_ATTEMPTS,
    timeout: config.CHUNK_TIMEOUT_MS,
    contactEmail: config.CONTACT_EMAIL
  });
});

/**
 * POST /api/generate-faq
 * Body: { chunks: string[], sources: string[], sessionId: string }
 * Parallel processes and extracts Q&A pairs.
 */
router.post('/api/generate-faq', async (req, res) => {
  const startTime = Date.now();
  let { chunks, sources, sessionId } = req.body;

  if (!chunks || !Array.isArray(chunks) || chunks.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid chunks array' });
  }

  const session = getOrCreateSession(sessionId);
  let skipped = 0;
  const allFaqs = [];

  // Create tasks for each chunk
  const tasks = chunks.map((chunk, index) => {
    const source = (sources && sources[index]) || 'Unknown Document';
    
    return async () => {
      // 10. Sanitize text chunk before feeding to LLM
      const sanitizedChunk = sanitizeInput(chunk);

      // Check if chunk got completely filtered out
      if (sanitizedChunk.trim() === '[input filtered]' || sanitizedChunk.length < 30) {
        skipped++;
        return;
      }

        const generateFn = async (modelName) => {
          const model = genAI.getGenerativeModel({ model: modelName });
          
          const systemPrompt = `You are an expert Q&A extraction system. 
Analyze the excerpt provided below and extract all possible question-and-answer pairs.
Requirements:
1. Extract maximum possible Q&A pairs (target 8 to 15 pairs).
2. The questions and answers MUST be derived strictly from facts explicitly stated in the excerpt. Do not fabricate, assume, or extrapolate any information.
3. Every question must be at least 9 characters long.
4. Every answer must be at least 9 characters long.
5. Return ONLY a valid JSON array of objects, where each object has "question" and "answer" keys.`;

          const prompt = `Source Document: ${source}\n\nExcerpt:\n${sanitizedChunk}`;

          const result = await model.generateContent({
            contents: [
              { role: 'user', parts: [{ text: `${systemPrompt}\n\n${prompt}` }] }
            ],
            generationConfig: {
              temperature: 0.2,
              responseMimeType: "application/json"
            }
          });

          return result.response.text();
        };

      try {
        // Run with retry/timeout/fallback wrapper
        const rawText = await executeResilientGemini(generateFn);

        const faqs = parseAndRecoverFAQs(rawText);
        faqs.forEach(item => {
          allFaqs.push({
            question: item.question,
            answer: item.answer,
            chunkIndex: index,
            source: source
          });
        });
      } catch (err) {
        console.error(`Failed to process chunk index ${index} after all retries:`, err);
        skipped++;
      }
    };
  });

  try {
    // Process in parallel with concurrency limit (e.g. 5)
    await limitConcurrency(tasks, config.PARALLEL_LIMIT);
    
    res.json({
      faqs: allFaqs,
      stats: {
        chunks: chunks.length,
        total: allFaqs.length,
        skipped: skipped,
        ms: Date.now() - startTime
      }
    });
  } catch (err) {
    console.error('Critical generation failure:', err);
    res.status(500).json({ error: 'FAQ generation failed entirely.' });
  }
});

/**
 * POST /api/answer
 * Body: { query, context, sessionId }
 * Gemini fallback answer with context & history
 */
router.post('/api/answer', async (req, res) => {
  let { query, context, sessionId } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  const session = getOrCreateSession(sessionId);

  // 10. Sanitize input to guard against injections
  const sanitizedQuery = sanitizeInput(query);
  const sanitizedContext = sanitizeInput(context || '');

  // Log to history
  updateSessionHistory(session, 'user', sanitizedQuery);

  const answerFn = async (modelName) => {
    const model = genAI.getGenerativeModel({
      model: modelName,
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 512  // cap output to reduce latency significantly
      }
    });

    // Compact system prompt - shorter = less tokens = faster
    const systemPrompt = `You are a concise customer support assistant.
Answer using ONLY the Document Context below. If the answer is not in the context, reply EXACTLY: "Sorry, I couldn't find an answer. Please contact us at ${config.CONTACT_EMAIL}"
Be direct and brief.`;

    const contents = [];

    // Pass only last 3 turns of history to reduce token count
    const recentHistory = buildHistory(session, 3);
    for (const h of recentHistory) {
      contents.push({ role: h.role, parts: [{ text: h.content }] });
    }

    // Truncate context to avoid bloating — max 800 chars
    const trimmedContext = sanitizedContext.slice(0, 800);

    contents.push({
      role: 'user',
      parts: [{ text: `${systemPrompt}\n\nContext:\n${trimmedContext}\n\nQuestion: ${sanitizedQuery}` }]
    });

    const result = await model.generateContent({ contents });
    return result.response.text();
  };

  try {
    const startTime = Date.now();
    const responseText = await executeFastResilientGemini(answerFn, 8000);
    console.log(`[Perf] /api/answer took ${Date.now() - startTime}ms`);
    
    const cleanAnswer = responseText.trim();
    
    // Store in session history
    updateSessionHistory(session, 'model', cleanAnswer);

    res.json({
      answer: cleanAnswer,
      sessionId: sessionId
    });
  } catch (err) {
    console.error('Answering endpoint failed:', err);
    res.json({
      answer: `Sorry, I couldn't find an answer. Please contact us at ${config.CONTACT_EMAIL}`,
      sessionId: sessionId
    });
  }
});

/**
 * POST /api/improve
 * Body: { query, context, previousAnswer, sessionId }
 * Generates an improved answers upon thumbs down trigger
 */
router.post('/api/improve', async (req, res) => {
  let { query, context, previousAnswer, sessionId } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  const session = getOrCreateSession(sessionId);

  // Sanitize
  const sanitizedQuery = sanitizeInput(query);
  const sanitizedContext = sanitizeInput(context || '');
  const sanitizedPrevAnswer = sanitizeInput(previousAnswer || '');

  const improveFn = async (modelName) => {
    const model = genAI.getGenerativeModel({
      model: modelName,
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 600
      }
    });

    const systemPrompt = `You are a helpful support assistant. The user was unsatisfied with a previous answer.
Provide a better, clearer answer using ONLY the Document Context below.
If you cannot improve it, reply EXACTLY: "Sorry, I couldn't find an answer. Please contact us at ${config.CONTACT_EMAIL}"`;

    // Truncate context and previous answer to control token usage
    const trimmedContext = sanitizedContext.slice(0, 800);
    const trimmedPrev = sanitizedPrevAnswer.slice(0, 300);

    const contents = [];
    const recentHistory = buildHistory(session, 2);
    for (const h of recentHistory) {
      contents.push({ role: h.role, parts: [{ text: h.content }] });
    }

    contents.push({
      role: 'user',
      parts: [{ text: `${systemPrompt}\n\nContext:\n${trimmedContext}\n\nPrevious Answer:\n${trimmedPrev}\n\nQuestion: ${sanitizedQuery}` }]
    });

    const result = await model.generateContent({ contents });
    return result.response.text();
  };

  try {
    const startTime = Date.now();
    const responseText = await executeFastResilientGemini(improveFn, 10000);
    console.log(`[Perf] /api/improve took ${Date.now() - startTime}ms`);
    
    const cleanAnswer = responseText.trim();
    
    // Replace the last model response in session history with this improved answer if possible
    if (session.history.length > 0 && session.history[session.history.length - 1].role === 'model') {
      session.history[session.history.length - 1].content = cleanAnswer;
    } else {
      updateSessionHistory(session, 'model', cleanAnswer);
    }

    res.json({
      answer: cleanAnswer,
      sessionId: sessionId
    });
  } catch (err) {
    console.error('Improve endpoint failed:', err);
    res.json({
      answer: `Sorry, I couldn't find an answer. Please contact us at ${config.CONTACT_EMAIL}`,
      sessionId: sessionId
    });
  }
});

export default router;
