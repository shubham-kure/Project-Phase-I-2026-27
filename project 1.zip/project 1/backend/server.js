import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { config } from './config.js';
import routes from './routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Apply CORS middleware
app.use(cors({
  origin: config.CORS_ORIGIN
}));

// Setup JSON body parsing with appropriate size limit for document uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Mount the API routes
app.use('/', routes);

// Serve the frontend statically from the peer directory
// Visiting http://localhost:3000 will serve the entire client app directly
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

// Fallback index.html router for SPA behavior
app.get('*', (req, res, next) => {
  // If it's an API request, skip static file redirect
  if (req.path.startsWith('/api') || req.path === '/health') {
    return next();
  }
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Centralized error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  
  const status = err.status || 500;
  res.status(status).json({
    error: err.message || 'An unexpected error occurred on the server.',
    status
  });
});

// Start listening
app.listen(config.PORT, () => {
  console.log(`==================================================`);
  console.log(`   FAQ Retrieval System Server Running!           `);
  console.log(`   URL: http://localhost:${config.PORT}           `);
  console.log(`   Model: ${config.GEMINI_MODEL}                  `);
  console.log(`==================================================`);
});
