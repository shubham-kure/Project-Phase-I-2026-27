/**
 * MAIN ORCHESTRATION MODULE - FAQ RETRIEVAL SYSTEM
 */
import { 
  chunkText, fmtSize, fileIcon, toast, loading, progress, 
  logLine, debounce, esc, uid, setBadge, idbSet, idbGet, idbClear 
} from './utils.js';
import { loadMiniLM, buildIndex, loadIndexFromCache, searchPhase1, searchPhase2, embedQuery } from './search.js';
import { initChat } from './chat.js';

// Application State
const state = {
  sessionId: uid(),
  files: [], // Array of { id, name, size, type, dataUrl, status, text, pagesCount }
  faqs: [],  // Active Q&A pairs: { question, answer, chunkIndex, source }
  searchIndex: null, // Holds indexObj
  bm25: null,        // Holds BM25 index
  groupsPagination: {}, // GroupName -> loadedCardsCount
  backendOnline: false,
  miniLMOnline: false,
  contactEmail: 'contact_us@mygmail.com'
};
window.S = state;

// DOM Anchors
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const browseBtn = document.getElementById('browse-btn');
const fileListContainer = document.getElementById('file-list-container');
const fileQueue = document.getElementById('file-queue');
const clearQueueBtn = document.getElementById('clear-queue-btn');
const generateBtn = document.getElementById('generate-btn');
const filterInput = document.getElementById('filter-input');
const filterCount = document.getElementById('filter-count');
const emptyFaqsState = document.getElementById('empty-faqs-state');
const faqGroupsContainer = document.getElementById('faq-groups-container');
const exportJsonBtn = document.getElementById('export-json-btn');
const searchInput = document.getElementById('search-input');
const searchBtn = document.querySelector('.search-btn-inner');
const searchClearBtn = document.getElementById('search-clear-btn');
const suggestionsBox = document.getElementById('suggestions-box');
const answerCard = document.getElementById('answer-presentation-card');
const answerSourceTitle = document.getElementById('answer-source-title');
const answerSourceName = document.getElementById('answer-source-name');
const answerSourceTag = document.getElementById('answer-source-tag');
const answerQuestion = document.getElementById('answer-question');
const answerBody = document.getElementById('answer-body');
const feedbackUpBtn = document.getElementById('feedback-up-btn');
const feedbackDownBtn = document.getElementById('feedback-down-btn');
const feedbackMessage = document.getElementById('feedback-message');
const relatedFaqsSection = document.getElementById('related-faqs-section');
const relatedFaqsList = document.getElementById('related-faqs-list');

// PDF.js worker setup
const pdfjsLib = window['pdfjs-dist/build/pdf'];
pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';

// API root url
const API_URL = ''; // local relative (we serve frontend statically from backend port 3000)

/**
 * Bootstraps the application on page load
 */
async function init() {
  // Optimization 1: Eager, non-blocking model loading
  // Do not await this! Let it run in background.
  loadMiniLM().then(ready => { state.miniLMOnline = ready; });

  loading(true, 'Initializing Local AI Engine...');

  // 1. Check Backend Connectivity
  await checkBackendHealth();

  // 2. Load Active FAQ Dataset (IndexedDB or default fallback JSON)
  await loadFaqDataset();

  // Bind Event Listeners
  setupEventListeners();
  setupSearch();
  initChat();

  loading(false);
  toast('Application boot completed', 'success');
}

/**
 * Checks backend API health and sets badges
 */
async function checkBackendHealth() {
  setBadge('backend', 'pending', '⏳ Checking');
  try {
    const res = await fetch(`${API_URL}/health`);
    if (res.ok) {
      const data = await res.json();
      state.backendOnline = true;
      if (data.contactEmail) {
        state.contactEmail = data.contactEmail;
      }
      setBadge('backend', 'success', '✅ Active');
    } else {
      throw new Error();
    }
  } catch (err) {
    state.backendOnline = false;
    setBadge('backend', 'error', '❌ Offline');
    toast('Backend offline. Please start Node.js server.', 'error');
  }
}

/**
 * Loads FAQs from IndexedDB, or preloads the 5 sample FAQs
 */
async function loadFaqDataset() {
  try {
    const cachedIndex = await idbGet('searchIndex');

    if (cachedIndex && Array.isArray(cachedIndex) && cachedIndex.length > 0) {
      const loaded = loadIndexFromCache(cachedIndex);
      state.searchIndex = loaded.index;
      state.bm25 = loaded.bm25;
      state.faqs = loaded.faqs;
    } else {
      // Load fallback JSON
      const response = await fetch('./faqData/faqs.json');
      if (response.ok) {
        state.faqs = await response.json();
        
        // Build index and bm25
        const { indexObj, bm25 } = await buildIndex(state.faqs);
        state.searchIndex = indexObj;
        state.bm25 = bm25;

        // Save initial load to IndexedDB
        await idbSet('searchIndex', state.searchIndex);
      }
    }
  } catch (err) {
    console.error('Failed to load initial FAQ dataset:', err);
    toast('Error loading knowledge base', 'error');
  }

  renderFaqGrid();
}

/**
 * Sets up all DOM event listeners (except search)
 */
function setupEventListeners() {
  // --- INGESTION & DRAG DROP ---
  browseBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', handleFileSelection);

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) {
      addFilesToQueue(e.dataTransfer.files);
    }
  });

  clearQueueBtn.addEventListener('click', () => {
    state.files = [];
    renderFileQueue();
    toast('Queue cleared', 'info');
  });

  generateBtn.addEventListener('click', runFAQGenerationPipeline);

  // --- FILTER & GRID BROWSER ---
  filterInput.addEventListener('input', debounce(() => {
    renderFaqGrid();
  }, 200));

  exportJsonBtn.addEventListener('click', exportFaqDataset);

  // --- FEEDBACK ROW ---
  feedbackUpBtn.addEventListener('click', handleThumbsUp);
  feedbackDownBtn.addEventListener('click', handleThumbsDown);
}

/**
 * Separated Search Event Listeners for UX Optimizations
 */
function setupSearch() {
  // Hide suggestions clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-box-wrapper')) {
      suggestionsBox.classList.add('hidden');
    }
  });

  // Optimization 2: Debounced pre-embedding while typing
  searchInput.addEventListener('input', debounce((e) => {
    const val = e.target.value;
    handleSearchAutocomplete(val);
    
    // Pre-embed in background if query is substantial
    if (val.trim().length > 3 && state.miniLMOnline) {
      embedQuery(val.trim()).catch(() => {});
    }
  }, 300));

  searchInput.addEventListener('focus', () => {
    if (searchInput.value.trim().length >= 2) {
      suggestionsBox.classList.remove('hidden');
    }
  });

  searchBtn.addEventListener('click', () => {
    if (!searchBtn.disabled) doSearch();
  });

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !searchBtn.disabled) {
      e.preventDefault();
      doSearch();
    }
  });

  searchClearBtn.addEventListener('click', () => {
    searchInput.value = '';
    searchClearBtn.classList.add('hidden');
    suggestionsBox.classList.add('hidden');
    searchInput.focus();
  });
}

/**
 * Ingestion: File selection handler
 */
function handleFileSelection(e) {
  if (e.target.files.length > 0) {
    addFilesToQueue(e.target.files);
    fileInput.value = ''; // reset
  }
}

/**
 * 1. Document Upload
 * Validates, handles duplicates, and pushes to queue
 */
function addFilesToQueue(fileList) {
  let addedAny = false;
  
  for (const file of fileList) {
    const ext = file.name.split('.').pop().toLowerCase();
    const allowed = ['pdf', 'txt', 'png', 'jpg', 'jpeg'];
    
    // Format support validation
    if (!allowed.includes(ext)) {
      toast(`Unsupported format: "${file.name}"`, 'error');
      continue;
    }

    // Duplicate detection: silently ignore
    const duplicate = state.files.find(f => f.name === file.name);
    if (duplicate) {
      continue;
    }

    // Create file object wrapper
    const fileObj = {
      id: uid(),
      name: file.name,
      size: file.size,
      type: file.type,
      rawFile: file,
      status: 'pending', // pending, ready, warning, failed
      text: '',
      pagesCount: 0
    };

    state.files.push(fileObj);
    addedAny = true;
  }

  if (addedAny) {
    renderFileQueue();
    toast('Queue updated with new documents', 'success');
  }
}

/**
 * Renders the File Queue UI list
 */
function renderFileQueue() {
  if (state.files.length === 0) {
    fileListContainer.classList.add('hidden');
    return;
  }

  fileListContainer.classList.remove('hidden');
  fileQueue.innerHTML = '';

  state.files.forEach(file => {
    const li = document.createElement('li');
    li.className = 'file-item';
    li.id = `file-item-${file.id}`;

    let badgeClass = 'badge-pending';
    let badgeText = '⏳ Pending';
    if (file.status === 'ready') { badgeClass = 'badge-success'; badgeText = '✅ Ready'; }
    if (file.status === 'warning') { badgeClass = 'badge-warning'; badgeText = '⚠️ Warning'; }
    if (file.status === 'failed') { badgeClass = 'badge-error'; badgeText = '❌ Failed'; }

    li.innerHTML = `
      <div class="file-info-group">
        <span class="file-emoji-icon">${fileIcon(file.name)}</span>
        <div class="file-meta">
          <span class="file-name" title="${esc(file.name)}">${esc(file.name)}</span>
          <span class="file-size">${fmtSize(file.size)}</span>
        </div>
      </div>
      <div class="file-actions-group">
        <span class="status-badge ${badgeClass} file-item-badge">${badgeText}</span>
        <button class="file-remove-btn" data-id="${file.id}">✕</button>
      </div>
    `;

    // Bind remove button
    li.querySelector('.file-remove-btn').addEventListener('click', (e) => {
      const fid = e.target.getAttribute('data-id');
      state.files = state.files.filter(f => f.id !== fid);
      renderFileQueue();
    });

    fileQueue.appendChild(li);
  });
}

/**
 * 2. Ingestion: Main text extraction router
 */
async function extractTextFromFile(fileObj) {
  logLine(`Extracting text from: ${fileObj.name}...`, 'info');
  
  const ext = fileObj.name.split('.').pop().toLowerCase();
  
  try {
    if (ext === 'txt') {
      return await extractTextFromTXT(fileObj);
    } else if (ext === 'pdf') {
      return await extractTextFromPDF(fileObj);
    } else {
      return await extractTextFromImage(fileObj);
    }
  } catch (err) {
    console.error(`Extraction failed for ${fileObj.name}:`, err);
    fileObj.status = 'failed';
    logLine(`Critical extraction failure: ${fileObj.name}`, 'error');
    return false;
  }
}

/**
 * Read Plain Text files
 */
function extractTextFromTXT(fileObj) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      fileObj.text = text;
      
      // TXT Validation: Warning if < 20 characters
      if (text.trim().length < 20) {
        fileObj.status = 'warning';
        logLine(`Warning: "${fileObj.name}" contains very little text (<20 chars).`, 'warning');
        toast(`"${fileObj.name}" has minimal content.`, 'warning');
      } else {
        fileObj.status = 'ready';
        logLine(`Extraction successful: ${fileObj.name} (${text.length} characters).`, 'success');
      }
      resolve(true);
    };
    reader.onerror = () => {
      fileObj.status = 'failed';
      resolve(false);
    };
    reader.readAsText(fileObj.rawFile);
  });
}

/**
 * 2. PDF.js PDF Text Extraction
 */
async function extractTextFromPDF(fileObj) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const arrayBuffer = e.target.result;
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        fileObj.pagesCount = pdf.numPages;
        
        let fullText = '';
        let textPagesCount = 0;
        
        logLine(`Parsing PDF "${fileObj.name}" containing ${pdf.numPages} pages...`, 'info');
        
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const content = await page.getTextContent();
          const pageText = content.items.map(item => item.str).join(' ');
          
          if (pageText.trim().length > 0) {
            fullText += pageText + '\n';
            textPagesCount++;
          }

          // Progress log page by page every 10 pages requirement
          if (pageNum % 10 === 0) {
            logLine(`Parsed ${pageNum} / ${pdf.numPages} pages of "${fileObj.name}"...`, 'info');
            progress(Math.round((pageNum / pdf.numPages) * 100), `PDF: ${pageNum}/${pdf.numPages}`);
          }
        }

        fileObj.text = fullText;
        
        // Calculate extracted text percentage
        const textPagesRatio = textPagesCount / pdf.numPages;

        if (pdf.numPages > 0 && textPagesCount === 0) {
          // Scanned PDF detection: 0 pages with text layers
          fileObj.status = 'warning';
          logLine(`Warning: "${fileObj.name}" appears to be a scanned PDF (0 pages contain digital text layer).`, 'warning');
          toast(`Scanned PDF: "${fileObj.name}" contains no select text layers.`, 'warning');
        } else if (textPagesRatio < 0.10) {
          // Partial scans: < 10% pages having text layers
          fileObj.status = 'warning';
          logLine(`Warning: "${fileObj.name}" contains digital text in only ${textPagesCount} of ${pdf.numPages} pages (<10%).`, 'warning');
          toast(`Partial Scan: "${fileObj.name}" digital text page count low.`, 'warning');
        } else {
          fileObj.status = 'ready';
          logLine(`PDF Text extracted: ${fileObj.name}. Retrieved ${textPagesCount}/${pdf.numPages} text layers.`, 'success');
        }
        resolve(true);
      } catch (err) {
        console.error('PDF.js parse failed:', err);
        fileObj.status = 'failed';
        logLine(`PDF parsing failed: ${fileObj.name}`, 'error');
        resolve(false);
      }
    };
    
    reader.onerror = () => {
      fileObj.status = 'failed';
      resolve(false);
    };
    reader.readAsArrayBuffer(fileObj.rawFile);
  });
}

/**
 * 2. Tesseract.js Image OCR Text Extraction
 */
async function extractTextFromImage(fileObj) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      const dataUrl = e.target.result;
      logLine(`Spawning local OCR engine for image: ${fileObj.name}...`, 'info');
      
      try {
        const worker = await Tesseract.createWorker({
          cacheMethod: 'none',
          workerPath: 'tesseract-worker.min.js',
          corePath: 'tesseract-core.wasm.js',
          logger: m => {
            if (m.status === 'recognizing text') {
              const pct = Math.round(m.progress * 100);
              progress(pct, `OCR running: ${pct}%`);
            }
          }
        });

        await worker.loadLanguage('eng');
        await worker.initialize('eng');
        
        const { data: { text, confidence } } = await worker.recognize(dataUrl);
        await worker.terminate();

        fileObj.text = text;
        logLine(`OCR finished on "${fileObj.name}" (Confidence: ${confidence}%).`, 'info');

        // Validation Rules: OCR low confidence (<40%) or short length (<20 chars)
        if (text.trim().length < 20) {
          fileObj.status = 'warning';
          logLine(`Warning: OCR text output for "${fileObj.name}" is very short (<20 chars).`, 'warning');
          toast(`Minimal image text: "${fileObj.name}".`, 'warning');
        } else if (confidence < 40) {
          fileObj.status = 'warning';
          logLine(`Warning: OCR confidence extremely low for "${fileObj.name}" (${confidence}%).`, 'warning');
          toast(`Low OCR confidence: "${fileObj.name}" (${confidence}%).`, 'warning');
        } else {
          fileObj.status = 'ready';
          logLine(`OCR Ingested successfully: ${fileObj.name}`, 'success');
        }
        resolve(true);
      } catch (err) {
        console.error('Tesseract.js crashed:', err);
        fileObj.status = 'failed';
        logLine(`OCR pipeline crashed for image: ${fileObj.name}`, 'error');
        resolve(false);
      }
    };

    reader.onerror = () => {
      fileObj.status = 'failed';
      resolve(false);
    };
    reader.readAsDataURL(fileObj.rawFile);
  });
}

/**
 * Ingestion: FAQ Generation Orchestrator
 */
async function runFAQGenerationPipeline() {
  if (state.files.length === 0) {
    toast('No documents added in queue', 'warning');
    return;
  }

  if (!state.backendOnline) {
    toast('Cannot generate. Express backend is offline.', 'error');
    return;
  }

  setBadge('generator', 'warning', '⏳ Running');
  progress(0, 'Beginning text ingestion...');
  
  // Show progress card and scroll to it
  const progressSection = document.getElementById('progress-section');
  progressSection.classList.remove('hidden');
  progressSection.scrollIntoView({ behavior: 'smooth' });

  // Clear progress logs
  document.getElementById('progress-log').innerHTML = '';
  logLine('--- PIPELINE STARTING ---', 'info');

  // Process all files in queue sequentially
  let extractCount = 0;
  for (let i = 0; i < state.files.length; i++) {
    const file = state.files[i];
    progress(Math.round((i / state.files.length) * 100), `Reading file ${i+1}/${state.files.length}`);
    const success = await extractTextFromFile(file);
    if (success) extractCount++;
    renderFileQueue(); // update statuses
  }

  logLine(`Extraction complete. ${extractCount} of ${state.files.length} documents processed.`, 'info');

  // Gather texts and perform chunking
  const allChunks = [];
  const allSources = [];

  state.files.forEach(file => {
    if (file.status === 'ready' || file.status === 'warning') {
      const chunks = chunkText(file.text);
      file.chunkCount = chunks.length;
      logLine(`Chunked "${file.name}" into ${chunks.length} segments.`, 'info');
      
      chunks.forEach(chunk => {
        allChunks.push(chunk);
        allSources.push(file.name);
      });
    }
  });

  // Validation: If no text was extracted at all, halt
  if (allChunks.length === 0) {
    setBadge('generator', 'error', '❌ Failed');
    progress(null);
    logLine('Generation aborted: No extractable text found in queue.', 'error');
    toast('All files produced no text. Aborting generation.', 'error');
    return;
  }

  logLine(`Sending ${allChunks.length} chunks to backend in a single parallel batch request...`, 'info');
  progress(70, 'Connecting with Gemini...');

  try {
    const response = await fetch(`${API_URL}/api/generate-faq`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chunks: allChunks,
        sources: allSources,
        sessionId: state.sessionId
      })
    });

    if (!response.ok) {
      throw new Error(`Server returned error ${response.status}`);
    }

    const result = await response.json();
    const generatedFaqs = result.faqs || [];
    const stats = result.stats || { skipped: 0 };

    logLine(`Faq pairs returned: ${generatedFaqs.length} total. (Skipped failed chunks: ${stats.skipped})`, 'success');
    
    if (stats.skipped > 0) {
      toast(`Some chunks (${stats.skipped}) failed Gemini extraction and were skipped.`, 'info');
    }

    if (generatedFaqs.length === 0) {
      throw new Error('Gemini returned zero FAQ pairs');
    }

    // 4. Update Grid and Local Embeddings at Runtime
    progress(85, 'Pre-computing client-side search embeddings...');
    logLine('Generating semantic Float32Array embeddings inside browser...', 'info');

    if (state.miniLMOnline) {
      const { indexObj, bm25 } = await buildIndex(generatedFaqs, (cur, total) => {
        progress(85 + Math.round((cur / total) * 10), `Embedding FAQs: ${cur}/${total}`);
      });
      logLine('Client-side embeddings computed successfully.', 'success');
      state.searchIndex = indexObj;
      state.bm25 = bm25;
    } else {
      logLine('Local MiniLM model offline. Skipping semantic precomputes.', 'warning');
      const { indexObj, bm25 } = await buildIndex(generatedFaqs);
      state.searchIndex = indexObj;
      state.bm25 = bm25;
    }

    // Set State
    state.faqs = generatedFaqs;

    // Cache generated FAQ dataset in IndexedDB
    await idbClear();
    await idbSet('searchIndex', state.searchIndex);

    progress(100, 'Generation completed!');
    logLine('Pipeline completed. Local knowledge base refreshed.', 'success');
    setBadge('generator', 'success', '✅ Idle');
    
    // Render and toast success
    renderFaqGrid();
    toast(`Successfully generated ${generatedFaqs.length} FAQ pairs!`, 'success');

    // Remove queue files on success to refresh interface
    state.files = [];
    setTimeout(() => {
      renderFileQueue();
      progress(null);
    }, 3000);

  } catch (err) {
    console.error('FAQ generation backend call failed:', err);
    setBadge('generator', 'error', '❌ Failed');
    progress(null);
    logLine(`Generation failed: ${err.message}`, 'error');
    toast(`Generation failed: ${err.message}`, 'error');
  }
}

/**
 * 5. FAQ Grid Browser Renderer
 * Grouped by source, paginated, and supports filter query input
 */
function renderFaqGrid() {
  const query = filterInput.value.trim().toLowerCase();
  
  // Clear Grid
  faqGroupsContainer.innerHTML = '';

  // Filter FAQs based on query on BOTH question and answer fields
  const filteredFaqs = state.faqs.filter(faq => {
    if (!query) return true;
    return faq.question.toLowerCase().includes(query) || 
           faq.answer.toLowerCase().includes(query);
  });

  // Update Badge Counts
  filterCount.textContent = `Showing ${filteredFaqs.length} of ${state.faqs.length} FAQs`;

  if (filteredFaqs.length === 0) {
    emptyFaqsState.classList.remove('hidden');
    return;
  }
  
  emptyFaqsState.classList.add('hidden');

  // Group items by source filename
  const groups = {};
  filteredFaqs.forEach(faq => {
    const src = faq.source || 'General Context';
    if (!groups[src]) groups[src] = [];
    groups[src].push(faq);
  });

  // Render each group
  Object.keys(groups).forEach(groupName => {
    const groupWrapper = document.createElement('div');
    groupWrapper.className = 'faq-group-wrapper';

    const groupHeader = document.createElement('div');
    groupHeader.className = 'faq-group-header';
    groupHeader.innerHTML = `
      <span class="faq-group-title">${esc(groupName)}</span>
      <span class="faq-group-count">${groups[groupName].length} pairs</span>
    `;
    groupWrapper.appendChild(groupHeader);

    const cardsGrid = document.createElement('div');
    cardsGrid.className = 'faq-cards-grid';

    // Pagination: Default 12 per group, Load More button triggers append
    const limit = state.groupsPagination[groupName] || 12;
    const groupItems = groups[groupName];
    const slicedItems = groupItems.slice(0, limit);

    slicedItems.forEach(faq => {
      const card = document.createElement('div');
      card.className = 'faq-card';
      card.innerHTML = `
        <div class="faq-card-q">${esc(faq.question)}</div>
        <div class="faq-card-a">${esc(faq.answer)}</div>
      `;

      // 5. Card click action: shows Q&A in search answer panel immediately
      card.addEventListener('click', () => {
        showLocalFaqAnswer(faq);
      });

      cardsGrid.appendChild(card);
    });

    // Render Load More Button if remaining cards exist in group
    if (groupItems.length > limit) {
      const loadMoreRow = document.createElement('div');
      loadMoreRow.className = 'load-more-row';
      
      const loadMoreBtn = document.createElement('button');
      loadMoreBtn.className = 'btn btn-secondary btn-small';
      loadMoreBtn.textContent = 'Load More';
      loadMoreBtn.addEventListener('click', () => {
        state.groupsPagination[groupName] = limit + 12;
        renderFaqGrid();
      });

      loadMoreRow.appendChild(loadMoreBtn);
      cardsGrid.appendChild(loadMoreRow);
    }

    groupWrapper.appendChild(cardsGrid);
    faqGroupsContainer.appendChild(groupWrapper);
  });
}

/**
 * Display FAQ item inside search panel instantly
 */
function showLocalFaqAnswer(faq) {
  answerCard.classList.remove('hidden');
  answerCard.scrollIntoView({ behavior: 'smooth' });

  answerQuestion.textContent = faq.question;
  answerBody.textContent = faq.answer;
  
  answerSourceTitle.textContent = 'Source Document';
  answerSourceName.textContent = faq.source || 'Knowledge base';
  
  answerSourceTag.className = 'source-tag source-tag-local';
  answerSourceTag.textContent = '⚡ Local Match';

  // Toggle feedback triggers
  feedbackMessage.classList.add('hidden');
  feedbackUpBtn.classList.remove('active-yes');
  feedbackDownBtn.classList.remove('active-no');

  // Load related FAQs
  renderRelatedFaqs(faq.question);
}

/**
 * 7. Search Input Autocomplete suggestions
 * Appends standard suggestions after 2 characters typed
 */
function handleSearchAutocomplete(query) {
  const text = query.trim().toLowerCase();
  if (text.length < 2) {
    suggestionsBox.innerHTML = '';
    suggestionsBox.classList.add('hidden');
    searchClearBtn.classList.add('hidden');
    return;
  }

  searchClearBtn.classList.remove('hidden');

  // Filter top 6 closest questions
  const matches = state.faqs
    .filter(f => f.question.toLowerCase().includes(text))
    .slice(0, 6);

  if (matches.length === 0) {
    suggestionsBox.innerHTML = '';
    suggestionsBox.classList.add('hidden');
    return;
  }

  suggestionsBox.innerHTML = '';
  suggestionsBox.classList.remove('hidden');

  matches.forEach(match => {
    const li = document.createElement('li');
    li.className = 'suggestion-item';
    li.textContent = match.question;
    li.addEventListener('click', () => {
      searchInput.value = match.question;
      suggestionsBox.classList.add('hidden');
      doSearch();
    });
    suggestionsBox.appendChild(li);
  });
}

/**
 * 6. Execute Hybrid Search Routing
 */
function updateSearchProgress(pct) {
  const bar = document.getElementById('search-progress');
  const fill = document.getElementById('search-progress-fill');
  if (!bar || !fill) return;
  if (pct > 0) {
    bar.classList.add('active');
    fill.style.width = `${pct}%`;
    if (pct >= 100) {
      setTimeout(() => bar.classList.remove('active'), 400);
    }
  } else {
    bar.classList.remove('active');
    fill.style.width = '0%';
  }
}

function showSkeleton() {
  answerCard.classList.remove('hidden');
  answerCard.classList.remove('updating');
  answerQuestion.textContent = 'Searching...';
  answerBody.innerHTML = `
    <div class="skeleton" style="width: 90%;"></div>
    <div class="skeleton" style="width: 100%;"></div>
    <div class="skeleton" style="width: 75%;"></div>
  `;
  answerSourceTitle.textContent = 'Analyzing Context';
  answerSourceName.textContent = '...';
  answerSourceTag.className = 'source-tag';
  answerSourceTag.textContent = '🔍 Working';
  
  feedbackMessage.classList.add('hidden');
  relatedFaqsSection.classList.add('hidden');
}

async function doSearch() {
  const query = searchInput.value.trim();
  suggestionsBox.classList.add('hidden');

  if (!query) {
    toast('Please enter a query in search box', 'warning');
    return;
  }

  // Layer 1: Search button spinner
  searchBtn.innerHTML = '<span class="btn-spinner"></span> Searching...';
  searchBtn.disabled = true;

  // Layer 2 & 3: Progress bar and Skeleton
  updateSearchProgress(20);
  showSkeleton();

  try {
    // Phase 1: Instant BM25 (Synchronous, t ~ 1ms)
    const phase1Results = searchPhase1(query, state.bm25, state.faqs);
    updateSearchProgress(50);
    
    // Show Phase 1 results if any exist
    if (phase1Results.length > 0) {
      const topP1 = phase1Results[0];
      answerCard.classList.add('updating');
      displayAnswerPanel({
        question: topP1.faq.question,
        answer: topP1.faq.answer,
        source: topP1.faq.source || 'Knowledge base',
        tagClass: 'source-tag-local',
        tagName: '⚡ Quick Result'
      });
      // Remove animation class after it plays
      setTimeout(() => answerCard.classList.remove('updating'), 200);
    }

    // Phase 2: Async Hybrid Search
    // This will wait for MiniLM embedding (or hit cache instantly)
    const phase2Results = await searchPhase2(query, state.searchIndex, state.bm25);
    updateSearchProgress(85);

    if (phase2Results.length === 0) {
      await performGeminiAnsweringFallback(query, '');
      updateSearchProgress(100);
      return;
    }

    const topResult = phase2Results[0];

    // Determine if we need to update the UI (only if top result changed)
    const needsUpdate = !phase1Results.length || phase1Results[0].faq.question !== topResult.faq.question;

    if (topResult.hybridScore >= 0.50) {
      // Local match — exact verbatim hit (score=1.0) OR clear semantic similarity (cosine ≥ 0.50)
      if (needsUpdate) {
        answerCard.classList.add('updating');
        displayAnswerPanel({
          question: topResult.faq.question,
          answer: topResult.faq.answer,
          source: topResult.faq.source || 'Knowledge base',
          tagClass: 'source-tag-local',
          tagName: '✨ Local Match'
        });
        setTimeout(() => answerCard.classList.remove('updating'), 200);
      } else {
        // Just update the tag to show it's now a full semantic match
        answerSourceTag.textContent = '✨ Local Match';
      }
      renderRelatedFaqs(query, phase2Results);
    } else {
      // Low confidence -> Gemini Fallback
      
      // Deduplicate context contexts passed to Gemini
      const uniqueFaqs = new Set();
      const matchingContexts = [];
      for (const r of phase2Results) {
        const hash = r.faq.question + r.faq.answer;
        if (!uniqueFaqs.has(hash)) {
          uniqueFaqs.add(hash);
          matchingContexts.push(`Question: ${r.faq.question}\nAnswer: ${r.faq.answer}`);
          if (matchingContexts.length === 3) break;
        }
      }

      await performGeminiAnsweringFallback(query, matchingContexts.join('\n\n'), phase2Results);
    }
  } catch (err) {
    console.error('Hybrid search execution crashed:', err);
    toast('Search failed entirely.', 'error');
  } finally {
    updateSearchProgress(100);
    searchBtn.innerHTML = 'Search';
    searchBtn.disabled = false;
  }
}

/**
 * Requests `/api/answer` for model fallbacks
 */
async function performGeminiAnsweringFallback(query, context, searchResults = []) {
  if (!state.backendOnline) {
    // If backend is offline, return contact email message directly
    displayAnswerPanel({
      question: query,
      answer: `Sorry, I couldn't find an answer. Please contact us at ${state.contactEmail}`,
      source: 'System Error',
      tagClass: 'source-tag-gemini',
      tagName: '🤖 Gemini'
    });
    return;
  }

  try {
    const response = await fetch(`${API_URL}/api/answer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: query,
        context: context,
        sessionId: state.sessionId
      })
    });

    if (!response.ok) throw new Error('API request failed');

    const result = await response.json();
    
    displayAnswerPanel({
      question: query,
      answer: result.answer,
      source: 'Gemini AI',
      tagClass: 'source-tag-gemini',
      tagName: '🤖 Gemini'
    });

    renderRelatedFaqs(query, searchResults);

  } catch (err) {
    console.error('Answering fallback failed:', err);
    displayAnswerPanel({
      question: query,
      answer: `Sorry, I couldn't find an answer. Please contact us at ${state.contactEmail}`,
      source: 'Network Error',
      tagClass: 'source-tag-gemini',
      tagName: '🤖 Gemini'
    });
  }
}

/**
 * Display Answer presentation card with custom attributes
 */
function displayAnswerPanel({ question, answer, source, tagClass, tagName }) {
  answerCard.classList.remove('hidden');
  answerCard.scrollIntoView({ behavior: 'smooth' });

  answerQuestion.textContent = question;
  answerBody.textContent = answer;
  
  answerSourceTitle.textContent = source === 'Gemini AI' ? 'AI Generated' : 'Source Document';
  answerSourceName.textContent = source;
  
  answerSourceTag.className = `source-tag ${tagClass}`;
  answerSourceTag.textContent = tagName;

  // Clear thumbs toggles
  feedbackMessage.classList.add('hidden');
  feedbackUpBtn.classList.remove('active-yes');
  feedbackDownBtn.classList.remove('active-no');
}

/**
 * Populate standard related questions (top 4, omitting top match)
 */
function renderRelatedFaqs(query, searchResults = []) {
  // If no search results provided, run a quick keyword lookup
  let list = searchResults;
  if (list.length === 0) {
    list = state.faqs
      .filter(f => f.question.toLowerCase().includes(query.toLowerCase()))
      .map(f => ({ faq: f }));
  }

  // Filter out the active showing question to avoid duplicates
  const activeQuestionText = answerQuestion.textContent.trim().toLowerCase();
  const filtered = list
    .filter(r => r.faq.question.toLowerCase() !== activeQuestionText)
    .slice(0, 4);

  if (filtered.length === 0) {
    relatedFaqsSection.classList.add('hidden');
    return;
  }

  relatedFaqsSection.classList.remove('hidden');
  relatedFaqsList.innerHTML = '';

  filtered.forEach(result => {
    const li = document.createElement('li');
    li.innerHTML = `<span class="related-faq-link">${esc(result.faq.question)}</span>`;
    li.querySelector('span').addEventListener('click', () => {
      showLocalFaqAnswer(result.faq);
    });
    relatedFaqsList.appendChild(li);
  });
}

/**
 * Feedback 👍: displays thank you message with no API trigger
 */
function handleThumbsUp() {
  feedbackUpBtn.classList.add('active-yes');
  feedbackDownBtn.classList.remove('active-no');
  
  feedbackMessage.textContent = 'Thanks for your feedback! 😊';
  feedbackMessage.classList.remove('hidden');
}

/**
 * Feedback 👎: requests `/api/improve` endpoint
 */
async function handleThumbsDown() {
  feedbackDownBtn.classList.add('active-no');
  feedbackUpBtn.classList.remove('active-yes');

  if (!state.backendOnline) {
    feedbackMessage.textContent = `Sorry, I couldn't find an answer. Please contact us at ${state.contactEmail}`;
    feedbackMessage.classList.remove('hidden');
    return;
  }

  loading(true, 'Improving response with Gemini...');

  // Search context
  const query = answerQuestion.textContent;
  const prevAnswer = answerBody.textContent;
  
  // Find top matching documents for context using hybrid search
  let context = '';
  try {
    const results = await searchPhase2(query, state.searchIndex, state.bm25, 3);
    context = results
      .slice(0, 3)
      .map(r => `Question: ${r.faq.question}\nAnswer: ${r.faq.answer}`)
      .join('\n\n');
  } catch {
    // If search fails, proceed without context
    context = '';
  }

  try {
    const response = await fetch(`${API_URL}/api/improve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: query,
        context: context,
        previousAnswer: prevAnswer,
        sessionId: state.sessionId
      })
    });

    if (!response.ok) throw new Error('Improve call failed');

    const result = await response.json();
    
    // Replace answer in place
    answerBody.textContent = result.answer;
    answerSourceTag.className = 'source-tag source-tag-improved';
    answerSourceTag.textContent = '✨ Improved';

    feedbackMessage.textContent = 'Factual answer improved successfully!';
    feedbackMessage.classList.remove('hidden');

  } catch (err) {
    console.error('Failed to improve answer:', err);
    // Display unanswerable email on error
    answerBody.textContent = `Sorry, I couldn't find an answer. Please contact us at ${state.contactEmail}`;
    answerSourceTag.className = 'source-tag source-tag-gemini';
    answerSourceTag.textContent = '🤖 Gemini';
  } finally {
    loading(false);
  }
}

/**
 * Export active FAQs dataset as download trigger faqs.json
 */
function exportFaqDataset() {
  if (state.faqs.length === 0) {
    toast('No FAQs available to export', 'warning');
    return;
  }

  try {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state.faqs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "faqs.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    toast('Dataset exported successfully', 'success');
  } catch (err) {
    console.error('Export failed:', err);
    toast('Failed to export FAQ dataset', 'error');
  }
}

// Bootstrap
window.addEventListener('DOMContentLoaded', init);
