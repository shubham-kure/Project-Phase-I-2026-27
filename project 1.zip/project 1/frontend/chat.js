// chat.js
import { searchPhase1, searchPhase2 } from './search.js';

// ── State
const chatState = {
  open: false,
  welcomeShown: false,
  msgIdCounter: 0,
  pendingQuery: null,
};

// ── DOM Elements
let bubble, panel, messagesArea, input, sendBtn, closeBtn, clearBtn, suggestionsArea, unreadBadge, progressFill;

// ── Public init (called from app.js)
export function initChat() {
  bubble = document.getElementById('chat-bubble');
  panel = document.getElementById('chat-panel');
  messagesArea = document.getElementById('chat-messages');
  input = document.getElementById('chat-input');
  sendBtn = document.getElementById('chat-send-btn');
  closeBtn = document.getElementById('chat-close-btn');
  clearBtn = document.getElementById('chat-clear-btn');
  suggestionsArea = document.getElementById('chat-suggestions');
  unreadBadge = document.getElementById('chat-unread');
  progressFill = document.getElementById('chat-progress-fill');

  // Event Listeners
  bubble.addEventListener('click', () => {
    if (chatState.open) closePanel();
    else openPanel();
  });

  closeBtn.addEventListener('click', closePanel);
  clearBtn.addEventListener('click', clearConversation);

  // Input auto-grow and enable/disable send
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    sendBtn.disabled = input.value.trim().length === 0;
  });

  // Enter to send
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!sendBtn.disabled) sendQuery();
    }
  });

  sendBtn.addEventListener('click', sendQuery);
}

// ── Helpers
function uid() {
  return Math.random().toString(36).substring(2, 9);
}

function scrollToBottom(force = false) {
  // Only scroll to bottom if user is already near the bottom, or if force is true
  const isNearBottom = messagesArea.scrollHeight - messagesArea.scrollTop - messagesArea.clientHeight < 50;
  if (force || isNearBottom) {
    messagesArea.scrollTo({ top: messagesArea.scrollHeight, behavior: 'smooth' });
  }
}

function getContextFromResults(results) {
  const uniqueFaqs = new Set();
  const matchingContexts = [];
  for (const r of results) {
    const hash = r.faq.question + r.faq.answer;
    if (!uniqueFaqs.has(hash)) {
      uniqueFaqs.add(hash);
      matchingContexts.push(`Question: ${r.faq.question}\nAnswer: ${r.faq.answer}`);
      if (matchingContexts.length === 3) break;
    }
  }
  return matchingContexts.join('\n\n');
}

// ── Panel open/close
function openPanel() {
  chatState.open = true;
  panel.classList.add('open');
  bubble.classList.add('open');
  panel.setAttribute('aria-hidden', 'false');
  unreadBadge.hidden = true;

  if (!chatState.welcomeShown) {
    chatState.welcomeShown = true;
    appendBotMessage("Hi! 👋 I'm your FAQ Assistant. Ask me anything about your uploaded documents, or pick a suggested question below.");
    renderSuggestions();
  }

  setTimeout(() => input.focus(), 300);
}

function closePanel() {
  chatState.open = false;
  panel.classList.remove('open');
  bubble.classList.remove('open');
  panel.setAttribute('aria-hidden', 'true');
}

function clearConversation() {
  messagesArea.innerHTML = '';
  chatState.welcomeShown = false;
  chatState.pendingQuery = null;
  suggestionsArea.innerHTML = '';
  // Re-trigger welcome
  if (chatState.open) {
    chatState.welcomeShown = true;
    appendBotMessage("Hi! 👋 I'm your FAQ Assistant. Ask me anything about your uploaded documents, or pick a suggested question below.");
    renderSuggestions();
  }
}

// ── Message rendering
function escapeHtml(unsafe) {
  return (unsafe || '').toString()
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function appendUserMessage(text) {
  const msg = document.createElement('div');
  msg.className = 'chat-msg chat-msg--user';
  msg.innerHTML = `
    <div class="chat-msg-bubble">${escapeHtml(text)}</div>
  `;
  messagesArea.appendChild(msg);
  scrollToBottom(true);
}

function appendBotMessage(text, queryForFeedback = null) {
  const msgId = 'msg-' + uid();
  const msg = document.createElement('div');
  msg.className = 'chat-msg chat-msg--bot';
  msg.setAttribute('data-msg-id', msgId);
  
  let feedbackHtml = '';
  if (queryForFeedback) {
    feedbackHtml = `
      <div class="chat-msg-actions">
        <button class="chat-fb-btn chat-fb-up" data-id="${msgId}" title="Helpful">👍</button>
        <button class="chat-fb-btn chat-fb-dn" data-id="${msgId}" title="Not helpful">👎</button>
        <span class="chat-fb-status" id="fb-${msgId}"></span>
      </div>
    `;
  }

  msg.innerHTML = `
    <div class="chat-bot-avatar">✨</div>
    <div class="chat-msg-content">
      <div class="chat-msg-bubble">${escapeHtml(text)}</div>
      ${feedbackHtml}
    </div>
  `;
  messagesArea.appendChild(msg);
  scrollToBottom(true);

  if (queryForFeedback) {
    setupMessageFeedback(msgId, queryForFeedback, text);
  }

  // Show unread badge if panel is closed
  if (!chatState.open) {
    unreadBadge.hidden = false;
  }
}

function showTyping() {
  if (document.getElementById('chat-typing')) return;
  const msg = document.createElement('div');
  msg.className = 'chat-msg chat-msg--bot chat-msg--typing';
  msg.id = 'chat-typing';
  msg.innerHTML = `
    <div class="chat-bot-avatar">✨</div>
    <div class="chat-msg-content">
      <div class="chat-msg-bubble">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>
    </div>
  `;
  messagesArea.appendChild(msg);
  scrollToBottom(true);
}

function removeTyping() {
  const typing = document.getElementById('chat-typing');
  if (typing) typing.remove();
}

function updateBotMessage(id, text) {
  const msg = document.querySelector(`.chat-msg[data-msg-id="${id}"] .chat-msg-bubble`);
  if (msg) {
    msg.textContent = text;
  }
}

// ── Answer pipeline
async function sendQuery() {
  const query = input.value.trim();
  if (!query) return;

  // Clear input
  input.value = '';
  input.style.height = 'auto';
  input.disabled = true;
  sendBtn.disabled = true;
  suggestionsArea.innerHTML = ''; // hide suggestions after first message

  await handleChatMessage(query);

  input.disabled = false;
  input.focus();
}

async function handleChatMessage(query) {
  appendUserMessage(query);
  showTyping();
  setChatProgress(20);

  const S = window.S || {};
  let finalAnswer = '';
  let finalContext = '';

  try {
    if (!S.faqs || S.faqs.length === 0) {
      // No FAQs loaded
      setChatProgress(80);
      finalAnswer = await fetchGeminiAnswer(query, '');
    } else {
      // 3. Phase 1 — BM25 instant (synchronous)
      const phase1 = searchPhase1(query, S.bm25, S.faqs, 5);
      setChatProgress(50);

      // 4. Phase 2 — Hybrid (MiniLM + BM25)
      let results = [];
      try {
        results = await searchPhase2(query, S.searchIndex, S.bm25, 5);
      } catch {
        results = phase1; // fallback to BM25 only if MiniLM fails
      }
      setChatProgress(80);

      const top = results[0];

      // 5. Route by score
      if (top && top.hybridScore >= 0.50) {
        finalAnswer = top.faq.answer;
        finalContext = getContextFromResults(results); // for feedback
      } else {
        // Gemini fallback
        finalContext = getContextFromResults(results);
        finalAnswer = await fetchGeminiAnswer(query, finalContext);
      }
    }
  } catch (err) {
    console.error('Chat pipeline failed:', err);
    finalAnswer = `Sorry, I couldn't find an answer. Please contact us at ${S.contactEmail || 'contact_us@mygmail.com'}`;
  }

  // 6. Remove typing indicator, show answer
  removeTyping();
  setChatProgress(100);
  
  // Provide query and finalAnswer to appendBotMessage for feedback wiring
  // We use chatState.pendingQuery to store context for the feedback handler implicitly,
  // or we can pass context through setupMessageFeedback. Let's pass query and use it.
  appendBotMessage(finalAnswer, { query, context: finalContext, previousAnswer: finalAnswer });
  
  setTimeout(() => resetChatProgress(), 300);
}

async function fetchGeminiAnswer(query, context) {
  const S = window.S || {};
  if (!S.backendOnline) {
    return `Sorry, I couldn't find an answer. Please contact us at ${S.contactEmail || 'contact_us@mygmail.com'}`;
  }

  try {
    const res = await fetch('/api/answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query,
        context,
        sessionId: S.sessionId
      })
    });
    if (!res.ok) throw new Error('API request failed');
    const data = await res.json();
    return data.answer;
  } catch (err) {
    console.error('fetchGeminiAnswer error:', err);
    return `Sorry, I couldn't find an answer. Please contact us at ${S.contactEmail || 'contact_us@mygmail.com'}`;
  }
}

// ── Feedback
function setupMessageFeedback(msgId, dataContext) {
  const upBtn = document.querySelector(`.chat-fb-up[data-id="${msgId}"]`);
  const dnBtn = document.querySelector(`.chat-fb-dn[data-id="${msgId}"]`);
  const status = document.getElementById(`fb-${msgId}`);
  if (!upBtn || !dnBtn) return;

  const disableButtons = () => {
    upBtn.disabled = true;
    dnBtn.disabled = true;
  };

  upBtn.addEventListener('click', () => {
    upBtn.classList.add('active');
    status.textContent = 'Thanks! 😊';
    disableButtons();
  });

  dnBtn.addEventListener('click', async () => {
    dnBtn.classList.add('active');
    disableButtons();
    
    // Trigger improve
    const S = window.S || {};
    if (!S.backendOnline) {
      updateBotMessage(msgId, `Sorry, I couldn't find an answer. Please contact us at ${S.contactEmail || 'contact_us@mygmail.com'}`);
      return;
    }

    // Show typing in place of the status text temporarily
    status.textContent = 'Improving...';
    
    try {
      const res = await fetch('/api/improve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: dataContext.query,
          context: dataContext.context,
          previousAnswer: dataContext.previousAnswer,
          sessionId: S.sessionId
        })
      });

      if (!res.ok) throw new Error('Improve API failed');
      const data = await res.json();
      
      updateBotMessage(msgId, data.answer);
      status.textContent = '✨ Improved';
    } catch (err) {
      console.error('Improve error:', err);
      updateBotMessage(msgId, `Sorry, I couldn't find an answer. Please contact us at ${S.contactEmail || 'contact_us@mygmail.com'}`);
      status.textContent = '';
    }
  });
}

// ── Suggestions
function renderSuggestions() {
  suggestionsArea.innerHTML = '';
  const S = window.S || {};
  let suggestions = [];

  if (S.faqs && S.faqs.length > 0) {
    const seenSources = new Set();
    for (const faq of S.faqs) {
      const src = faq.source || 'unknown';
      if (!seenSources.has(src)) {
        seenSources.add(src);
        suggestions.push(faq.question);
        if (suggestions.length >= 4) break;
      }
    }
    // Pad with more if less than 4 unique sources
    for (const faq of S.faqs) {
      if (suggestions.length >= 4) break;
      if (!suggestions.includes(faq.question)) {
        suggestions.push(faq.question);
      }
    }
  } else {
    suggestions = [
      "What documents have been uploaded?",
      "How does the search work?",
      "What file types are supported?",
      "How do I get the best results?"
    ];
  }

  suggestions.forEach(q => {
    const pill = document.createElement('button');
    pill.className = 'chat-suggestion-pill';
    pill.textContent = q;
    pill.title = q; // For full text on hover if truncated
    pill.addEventListener('click', () => {
      input.value = q;
      sendBtn.disabled = false;
      sendQuery();
    });
    suggestionsArea.appendChild(pill);
  });
}

// ── Progress
function setChatProgress(pct) {
  progressFill.classList.add('active');
  progressFill.style.opacity = '1';
  progressFill.style.width = `${pct}%`;
}

function resetChatProgress() {
  progressFill.style.opacity = '0';
  setTimeout(() => {
    progressFill.style.width = '0%';
    progressFill.classList.remove('active');
  }, 300);
}
