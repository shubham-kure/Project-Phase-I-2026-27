/**
 * LOCAL AI EMBEDDINGS & SEARCH SCORING SYSTEM
 */
import { setBadge, toast } from './utils.js';

let extractor = null;
let miniLMPromise = null;

// Query Embeddings LRU Cache (Max 100 entries)
const queryCache = new Map();

/**
 * 1. Optimization 1 - MiniLM Loading (Invisible, Singleton, Pre-warm)
 */
export function loadMiniLM() {
  if (miniLMPromise) return miniLMPromise;

  miniLMPromise = (async () => {
    setBadge('minilm', 'warning', '⏳ Loading...');
    try {
      const { pipeline, env } = await import('https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2');
      env.allowLocalModels = false;
      env.useBrowserCache = true;

      extractor = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
      
      // Pre-warm with 3 diverse sentences to fully initialize all model layers and tokenizer
      // This eliminates the 1-3s cold start delay on the user's first query
      await extractor(["what is", "how to", "explain the process of"], { pooling: 'mean', normalize: true });
      
      setBadge('minilm', 'success', '✅ Ready');
      return true;
    } catch (err) {
      setBadge('minilm', 'error', '❌ Failed');
      return false;
    }
  })();
  
  return miniLMPromise;
}

/**
 * Batch embed multiple texts
 */
export async function embedTexts(texts, onProgress) {
  if (!extractor) await loadMiniLM();
  if (!extractor) throw new Error('MiniLM not loaded');
  
  const BATCH_SIZE = 64;
  const embeddings = [];
  
  for (let i = 0; i < texts.length; i += BATCH_SIZE) {
    const batch = texts.slice(i, i + BATCH_SIZE);
    
    // Xenova's extractor can process an array of strings natively
    const output = await extractor(batch, { pooling: 'mean', normalize: true });
    
    // Output.data is a flattened Float32Array. We need to chunk it back into individual Float32Arrays.
    const dim = 384;
    for (let j = 0; j < batch.length; j++) {
      const vec = new Float32Array(dim);
      vec.set(output.data.subarray(j * dim, (j + 1) * dim));
      embeddings.push(vec);
    }

    if (onProgress) {
      onProgress(Math.min(i + BATCH_SIZE, texts.length), texts.length);
    }
  }
  return embeddings;
}

/**
 * 2. Optimization 2 - Query Embedding with Smart LRU Cache
 */
export async function embedQuery(text) {
  if (!extractor) return null;
  const key = text.toLowerCase().trim();
  if (!key) return null;

  if (queryCache.has(key)) {
    // LRU: Move to end (most recently used)
    const val = queryCache.get(key);
    queryCache.delete(key);
    queryCache.set(key, val);
    return val;
  }

  const emb = (await embedTexts([text]))[0];
  
  if (queryCache.size >= 100) {
    // Evict oldest (first entry)
    queryCache.delete(queryCache.keys().next().value);
  }
  queryCache.set(key, emb);
  return emb;
}

/**
 * Normalize vector (L2 norm) so cosine similarity = dot product
 */
export function normalizeVec(v) {
  let s = 0;
  for (let i = 0; i < v.length; i++) s += v[i] * v[i];
  const norm = Math.sqrt(s);
  if (norm > 0) {
    for (let i = 0; i < v.length; i++) v[i] /= norm;
  }
  return v;
}

/**
 * 3. Optimization 3 - SIMD-style Batched Dot Product
 * Uses Float32Array and unrolled loop for massive speedup.
 */
export function fastDotProduct(qEmb, emb) {
  let dot = 0;
  const len = emb.length; // 384
  let j = 0;
  // Unrolled loop (4x)
  for (; j < len - 3; j += 4) {
    dot += qEmb[j]   * emb[j]
         + qEmb[j+1] * emb[j+1]
         + qEmb[j+2] * emb[j+2]
         + qEmb[j+3] * emb[j+3];
  }
  // Remainder
  for (; j < len; j++) dot += qEmb[j] * emb[j];
  return dot;
}

/**
 * Fast Pure JS BM25 Implementation
 */
export function buildBM25Index(faqs) {
  const stopWords = new Set([
    'a', 'an', 'and', 'are', 'as', 'at', 'be', 'but', 'by', 'for', 'if', 'in', 
    'into', 'is', 'it', 'no', 'not', 'of', 'on', 'or', 'such', 'that', 'the', 
    'their', 'then', 'there', 'these', 'they', 'this', 'to', 'was', 'will', 'with'
  ]);
  
  const tokenize = (text) => {
    if (!text) return [];
    return text.toLowerCase().replace(/[^\w\s-]/g, '').split(/\s+/).filter(w => w.length > 1 && !stopWords.has(w));
  };

  const docLengths = new Int32Array(faqs.length);
  const docTermFreqs = [];
  const docFreqs = new Map();
  let totalLen = 0;

  faqs.forEach((faq, i) => {
    const tokens = tokenize(faq.question + " " + faq.answer);
    docLengths[i] = tokens.length;
    totalLen += tokens.length;
    
    const termMap = new Map();
    const unique = new Set(tokens);
    for (const t of tokens) termMap.set(t, (termMap.get(t) || 0) + 1);
    docTermFreqs.push(termMap);

    for (const t of unique) docFreqs.set(t, (docFreqs.get(t) || 0) + 1);
  });

  const avgDocLength = totalLen / (faqs.length || 1);
  const docCount = faqs.length;

  return {
    tokenize,
    docLengths,
    docTermFreqs,
    docFreqs,
    avgDocLength,
    docCount
  };
}

export function bm25Score(query, bm25, docIdx, k1 = 1.2, b = 0.75) {
  const queryTerms = bm25.tokenize(query);
  const docLen = bm25.docLengths[docIdx] || 0;
  const termMap = bm25.docTermFreqs[docIdx];
  let score = 0;

  for (const term of queryTerms) {
    if (!bm25.docFreqs.has(term)) continue;
    const tf = termMap.get(term) || 0;
    const df = bm25.docFreqs.get(term);
    const idf = Math.log(1 + (bm25.docCount - df + 0.5) / (df + 0.5));
    score += idf * ((tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (docLen / bm25.avgDocLength))));
  }
  return score;
}

/**
 * 4. Build Index & IDB Caching
 */
export async function buildIndex(faqs, onProgress) {
  // Pre-compute embeddings for all FAQs
  const texts = faqs.map(f => f.question);
  let embeddings = [];
  try {
    embeddings = await embedTexts(texts, onProgress);
    // Ensure all embeddings are normalized Float32Arrays for fast dot product
    embeddings = embeddings.map(normalizeVec);
  } catch (err) {
    console.error("Embedding generation failed", err);
  }

  // IDB Serialization Fix: Convert Float32Array to regular Array for IDB
  const indexObj = faqs.map((faq, i) => ({
    faq,
    emb: embeddings[i] ? Array.from(embeddings[i]) : null
  }));

  // Create BM25 index synchronously
  const bm25 = buildBM25Index(faqs);
  
  return { indexObj, bm25 };
}

export function loadIndexFromCache(cachedItems) {
  // Convert IDB Arrays back to Float32Arrays for fast SIMD operations
  const faqs = [];
  const index = cachedItems.map(item => {
    faqs.push(item.faq);
    return {
      faq: item.faq,
      emb: item.emb ? new Float32Array(item.emb) : null
    };
  });
  const bm25 = buildBM25Index(faqs);
  return { index, bm25, faqs };
}

/**
 * Phase 1: Synchronous BM25-only Search (Returns immediately < 1ms)
 */
export function searchPhase1(query, bm25, faqs, topN = 5) {
  if (!query || !faqs || faqs.length === 0) return [];

  const results = [];
  for (let i = 0; i < faqs.length; i++) {
    results.push({
      faq: faqs[i],
      index: i,
      bm25Score: bm25Score(query, bm25, i),
      semanticScore: 0,
      hybridScore: 0
    });
  }

  // Sort purely by BM25
  results.sort((a, b) => b.bm25Score - a.bm25Score);
  
  // Update hybridScore for compatibility with UI
  results.forEach(r => r.hybridScore = r.bm25Score);
  
  return results.slice(0, topN);
}

/**
 * Phase 2: Async Hybrid Search
 *
 * Ranking  → Reciprocal Rank Fusion (RRF, k=60)
 *            Industry standard used by Elasticsearch 8.x, Pinecone, Cohere.
 *            Combines BM25 rank + Semantic rank without any score-scale mismatch.
 *
 * Routing  → Dual-signal confidence check (determines local vs Gemini fallback):
 *            1. Exact verbatim match  → always serve locally  (confidence = 1.0)
 *            2. Semantic cosine ≥ 0.50 → serve locally        (clear semantic match)
 *            3. Neither               → Gemini fallback
 *            `hybridScore` on each result carries this confidence value.
 */
export async function searchPhase2(query, index, bm25, topN = 5) {
  if (!query || !index || index.length === 0) return [];

  const n = index.length;
  const K = 60; // Standard RRF constant

  // ── 1. BM25 scores & rankings ────────────────────────────────────────────
  const rawBm25 = new Float32Array(n);
  for (let i = 0; i < n; i++) rawBm25[i] = bm25Score(query, bm25, i);

  // Sort indices by descending BM25 score to get rank
  const bm25Order = Array.from({ length: n }, (_, i) => i)
    .sort((a, b) => rawBm25[b] - rawBm25[a]);
  const bm25RankOf = new Int32Array(n);
  bm25Order.forEach((docIdx, rank) => { bm25RankOf[docIdx] = rank; });

  // ── 2. Semantic scores & rankings ────────────────────────────────────────
  const semScores = new Float32Array(n);
  let qEmb = null;

  if (extractor) {
    try {
      qEmb = await embedQuery(query);
      if (qEmb) {
        qEmb = normalizeVec(qEmb);
        for (let i = 0; i < n; i++) {
          if (index[i].emb) {
            semScores[i] = Math.max(0, fastDotProduct(qEmb, index[i].emb));
          }
        }
      }
    } catch (_) { /* Model offline — BM25-only path */ }
  }

  const semOrder = Array.from({ length: n }, (_, i) => i)
    .sort((a, b) => semScores[b] - semScores[a]);
  const semRankOf = new Int32Array(n);
  semOrder.forEach((docIdx, rank) => { semRankOf[docIdx] = rank; });

  // ── 3. Exact-term lookup (covers acronyms, codes, names) ─────────────────
  const queryLower = query.toLowerCase().trim();

  // ── 4. Fuse with RRF + compute routing confidence ─────────────────────────
  const results = [];
  for (let i = 0; i < n; i++) {
    const item = index[i];

    // RRF score — ranks both signals equally, no scale mismatch
    const rrfBm25 = 1 / (K + bm25RankOf[i] + 1);
    const rrfSem  = qEmb ? 1 / (K + semRankOf[i] + 1) : 0;
    const rrfScore = rrfBm25 + rrfSem;

    // Routing confidence — clean dual-signal check:
    //   exact verbatim presence → 1.0 (always local)
    //   otherwise → raw cosine similarity (0–1 scale)
    const faqText = ((item.faq.question || '') + ' ' + (item.faq.answer || '')).toLowerCase();
    const isExactMatch = faqText.includes(queryLower);
    const hybridScore = isExactMatch ? 1.0 : semScores[i];

    results.push({
      faq: item.faq,
      index: i,
      bm25Score: rawBm25[i],
      semanticScore: semScores[i],
      hybridScore,   // used by routing logic in app.js / chat.js
      rrfScore,      // used for ordering — highest RRF = most relevant
      isExactMatch
    });
  }

  // Sort by RRF (best combined rank first)
  results.sort((a, b) => b.rrfScore - a.rrfScore);
  return results.slice(0, topN);
}
