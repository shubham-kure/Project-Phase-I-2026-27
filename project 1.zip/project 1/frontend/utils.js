/**
 * UTILITY FUNCTIONS - FAQ RETRIEVAL SYSTEM
 */

// 1. Text Chunking Utility
export function chunkText(text) {
  if (!text) return [];
  
  // Regex to split text into sentences while preserving standard endings (. ! ?)
  const sentences = text.match(/[^.!?]+[.!?]+(?:\s|$)/g) || [text];
  
  const chunks = [];
  let currentChunk = [];
  let currentWordCount = 0;

  for (const sentence of sentences) {
    const words = sentence.trim().split(/\s+/).filter(Boolean);
    const wordCount = words.length;
    if (wordCount === 0) continue;

    // Check if adding this sentence pushes the chunk past 200 words
    if (currentWordCount + wordCount > 200 && currentWordCount >= 30) {
      chunks.push(currentChunk.join('').trim());
      currentChunk = [];
      currentWordCount = 0;
    }

    currentChunk.push(sentence);
    currentWordCount += wordCount;
  }

  // Push final remaining block
  if (currentChunk.length > 0) {
    const remainingText = currentChunk.join('').trim();
    const remainingWords = remainingText.split(/\s+/).filter(Boolean).length;
    // Skip chunks < 30 words
    if (remainingWords >= 30) {
      chunks.push(remainingText);
    }
  }

  return chunks;
}

// 2. Format File Sizes Nicely
export function fmtSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 3. Emojis for Document Type Icons
export function fileIcon(fileName) {
  const ext = fileName.split('.').pop().toLowerCase();
  switch (ext) {
    case 'pdf':
      return '📕';
    case 'txt':
      return '📄';
    case 'png':
    case 'jpg':
    case 'jpeg':
      return '🖼️';
    default:
      return '📁';
  }
}

// 4. Beautiful, Animated Auto-dismiss Toasts
export function toast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toastEl = document.createElement('div');
  toastEl.className = `toast toast-${type}`;
  
  let emoji = 'ℹ️';
  if (type === 'success') emoji = '✅';
  if (type === 'error') emoji = '❌';
  if (type === 'warning') emoji = '⚠️';

  toastEl.innerHTML = `
    <span class="toast-emoji">${emoji}</span>
    <span class="toast-message">${esc(message)}</span>
  `;

  container.appendChild(toastEl);

  // Trigger CSS enter animation
  setTimeout(() => toastEl.classList.add('visible'), 10);

  // Auto-remove after 4 seconds
  setTimeout(() => {
    toastEl.classList.remove('visible');
    toastEl.addEventListener('transitionend', () => toastEl.remove());
  }, 4000);
}

// 5. Full Screen Loading Indicator
export function loading(show, text = 'Loading...') {
  const overlay = document.getElementById('loading-overlay');
  const label = document.getElementById('loading-label');
  if (!overlay) return;

  if (show) {
    if (label) label.textContent = text;
    overlay.classList.add('visible');
  } else {
    overlay.classList.remove('visible');
  }
}

// 6. Progress Bar Modifier
export function progress(percent, text) {
  const container = document.getElementById('progress-section');
  const bar = document.getElementById('progress-bar-fill');
  const textEl = document.getElementById('progress-text');
  const pctEl = document.getElementById('progress-percent');

  if (!container || !bar) return;

  if (percent === null || percent < 0) {
    container.classList.add('hidden');
    return;
  }

  container.classList.remove('hidden');
  bar.style.width = `${percent}%`;
  if (textEl && text) textEl.textContent = text;
  if (pctEl) pctEl.textContent = `${Math.round(percent)}%`;
}

// 7. Monospace Progress Logging System
export function logLine(text, level = 'info') {
  const logBox = document.getElementById('progress-log');
  if (!logBox) return;

  const line = document.createElement('div');
  line.className = `log-line log-${level}`;
  
  const time = new Date().toLocaleTimeString();
  line.innerHTML = `<span class="log-time">[${time}]</span> <span class="log-text">${esc(text)}</span>`;
  
  logBox.appendChild(line);
  // Auto-scroll to bottom
  logBox.scrollTop = logBox.scrollHeight;
}

// 8. Standard Debounce
export function debounce(fn, delay) {
  let timer = null;
  return function (...args) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

// 9. Simple HTML Escaper
export function esc(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// 10. Random 8-character ID Generator
export function uid() {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

// 11. Header Status Badges Updater
export function setBadge(id, status, label) {
  const badge = document.getElementById(`badge-${id}`);
  if (!badge) return;

  badge.className = `status-badge badge-${status}`;
  badge.textContent = label;
}

// 12. Cosine Similarity Typed Array Calculator
export function cosine(vecA, vecB) {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  
  let dotProduct = 0.0;
  let normA = 0.0;
  let normB = 0.0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// 13. Promise-based IndexedDB Key-Value Helper
const DB_NAME = 'FAQ_RETRIEVAL_DB';
const STORE_NAME = 'faq_store';

function getDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = (e) => resolve(e.target.result);
    request.onerror = (e) => reject(e.target.error);
  });
}

export async function idbSet(key, value) {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(value, key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('IndexedDB set failed:', err);
  }
}

export async function idbGet(key) {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('IndexedDB get failed:', err);
    return null;
  }
}

export async function idbClear() {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('IndexedDB clear failed:', err);
  }
}
